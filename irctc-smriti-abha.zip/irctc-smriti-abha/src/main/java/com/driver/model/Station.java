package com.driver.model;

public enum Station {

    JAMMU,
    JALANDHAR,
    LUDHIANA,
    DELHI,
    KANPUR,
    AGRA,
    MATHURA,
    GWALIOR,
    NAGPUR,
    MUMBAI,
    PUNE,
    CHENNAI,
    TIPURATI,
    KANYAKUMARI,
    PRAYAGRAJ,
    VARANASI,
    DARJELLING,
    KOLKATA
}
